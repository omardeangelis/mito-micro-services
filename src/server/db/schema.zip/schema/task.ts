import { relations, sql } from "drizzle-orm"
import {
  pgTableCreator,
  timestamp,
  integer,
  serial,
  pgEnum,
  varchar,
} from "drizzle-orm/pg-core"
import { customers } from "./customers"
import { operators } from "./operators"

export const taskStatus = ["unset", "active", "done"] as const

export const taskStatusEnum = pgEnum("task_status", taskStatus)

const createTable = pgTableCreator((name) => `mito-deutsche_${name}`)

export const task = createTable("task", {
  id: serial("id").primaryKey().notNull(),
  createdAt: timestamp("created_at")
    .default(sql`CURRENT_TIMESTAMP`)
    .notNull(),
  updatedAt: timestamp("updated_at")
    .default(sql`CURRENT_TIMESTAMP`)
    .notNull()
    .$onUpdate(() => new Date()),
  state: taskStatusEnum("state").default("unset"),
  closedAt: timestamp("closed_at"),
  customerId: varchar("customer_id").references(() => customers.id),
  operatorId: integer("operator_id").references(() => operators.id),
})

export const taskRelations = relations(task, ({ one }) => ({
  customer: one(customers, {
    fields: [task.customerId],
    references: [customers.id],
  }),
  operator: one(operators, {
    fields: [task.operatorId],
    references: [operators.id],
  }),
}))
