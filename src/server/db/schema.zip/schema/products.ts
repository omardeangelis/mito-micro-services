import { relations, sql } from "drizzle-orm"
import {
  char,
  pgTableCreator,
  serial,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core"
import { practices } from "./pratiche"

const createTable = pgTableCreator((name) => `mito-deutsche_${name}`)

export const products = createTable("products", {
  id: serial("id").primaryKey().notNull(),
  productCode: char("product_code", { length: 2 }).notNull(),
  productLabel: varchar("product_label"),
  productType: varchar("product_type"),
  createdAt: timestamp("created_at")
    .default(sql`CURRENT_TIMESTAMP`)
    .notNull(),
  updatedAt: timestamp("updated_at").$onUpdate(() => new Date()),
})

export const productsRelations = relations(products, ({ many }) => ({
  practices: many(practices),
}))
